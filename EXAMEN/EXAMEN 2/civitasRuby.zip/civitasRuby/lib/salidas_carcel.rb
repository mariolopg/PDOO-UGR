module Civitas
    module Salidas_carcel
        
        PAGANDO = :pagando
        TIRANDO = :tirando
           
    end
    Lista_salidas_carcel = [Salidas_carcel::PAGANDO, Salidas_carcel::TIRANDO]
  end