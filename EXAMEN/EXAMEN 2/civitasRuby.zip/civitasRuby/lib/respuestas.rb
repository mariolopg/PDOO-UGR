module Civitas
    module Respuestas
        
        SI = :si
        NO = :no

    end
    Lista_respuestas = [ Respuestas::SI, Respuestas::NO ]
  end