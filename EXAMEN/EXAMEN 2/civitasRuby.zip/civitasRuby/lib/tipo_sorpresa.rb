# encoding:utf-8
 module Civitas
  module Tipo_sorpresa
    IRCARCEL = :ir_carcel
    IRCASILLA = :ir_casilla
    PAGARCOBRAR = :pagar_cobrar
    PORJUGADOR = :por_jugador
    PORCASAHOTEL = :por_casa_hotel
    SALIRCARCEL = :salir_carcel
  end
end
