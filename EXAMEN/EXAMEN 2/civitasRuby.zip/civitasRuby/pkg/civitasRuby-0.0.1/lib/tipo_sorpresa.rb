# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

 module Civitas
  module TipoSorpresa
    IRCARCEL = :ir_carcel
    IRCASILLA = :ir_casilla
    PAGARCOBRAR = :pagar_cobrar
    PORJUGADOR = :por_jugador
    SALIRCARCEL = :salir_carcel
  end
end
